/*****************************************
** File:    Country.cpp
** Project: CSCE 221 Project 0, Spring 2019
** Author:  Eric Weiss
** Date:    1/23/19
** Section: 512
** E-mail:  ericweiss98@tamu.edu 
**
**   This file contains the Country class function definitions
**
***********************************************/

#include "Country.h"

#include <iostream>
#include <vector>
#include <string>

using namespace std;

Country::Country() {}

Country::Country(string newName) {
	name = newName;
}

string Country::getName() const {
	return name;
}

long Country::getPopulation() const {
	return population;
}

float Country::getLiteracyRate() const {
	return literacyRate;
}

float Country::getPrimaryCompletionFemale() const {
	return primaryCompletionFemale;
}

float Country::getPrimaryCompletionMale() const {
	return primaryCompletionMale;
}

float Country::getPrimaryCompletionTotal() const {
	return primaryCompletionTotal;
}

float Country::getEducationGDPSpent() const {
	return educationGDPSpent;
}

float Country::getYouthLitRateFem() const {
	return youthLitRateFem;
}

float Country::getYouthLitRateMale() const {
	return youthLitRateMale;
}

void Country::setName(string newName) {
	name = newName;
}

void Country::setPopulation(long newPopulation) {
	population = newPopulation;
}

void Country::setLiteracyRate(float newLiteracyRate) {
	//cout << "running function; old LitRate = " << literacyRate << '\n';
	this->literacyRate = newLiteracyRate;
	//cout << "running function; new LitRate = " << literacyRate << '\n';
}

void Country::setPrimaryCompletionFemale(float newPrimaryCompletionFemale) {
	primaryCompletionFemale = newPrimaryCompletionFemale;
}

void Country::setPrimaryCompletionMale(float newPrimaryCompletionMale) {
	primaryCompletionMale = newPrimaryCompletionMale;
}

void Country::setPrimaryCompletionTotal(float newPrimaryCompletionTotal) {
	primaryCompletionTotal = newPrimaryCompletionTotal;
}

void Country::setEducationGDPSpent(float newEducationGDPSpent) {
	educationGDPSpent = newEducationGDPSpent;
}

void Country::setYouthLitRateFem(float newYouthLitRateFem) {
	youthLitRateFem = newYouthLitRateFem;
}

void Country::setYouthLitRateMale(float newYouthLitRateMale) {
	youthLitRateMale = newYouthLitRateMale;
}