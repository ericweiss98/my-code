/*****************************************
** File:    Continent.cpp
** Project: CSCE 221 Project 0, Spring 2019
** Author:  Eric Weiss
** Date:    1/23/19
** Section: 512
** E-mail:  ericweiss98@tamu.edu 
**
**   This file contains the Continent class functions & overloaded operator definitions
**
***********************************************/

#include "Country.h"
#include "Continent.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

Continent::Continent(string newName) {
	name = newName;
}

string Continent::getName() const {
	return name;
}

int Continent::getCountriesInContinent() const {
	return countriesInContinent.size();
}

Country Continent::getCountryInContinent(int vectorPos) const {
	return countriesInContinent.at(vectorPos);
}

long Continent::getTotalPopulation() const {
	long totalPop = 0;
	
	for(int i = 0; i < countriesInContinent.size(); ++i) {
		totalPop += countriesInContinent.at(i).getPopulation();
	}
	
	return totalPop;
}

int Continent::getHighestPopulation() const {
	
	int highPopulation = countriesInContinent.at(0).getPopulation();
	int highestCountry = 0;
	
	for(int i = 1; i < countriesInContinent.size(); ++i) {
		if(highPopulation < countriesInContinent.at(i).getPopulation()) {
			highPopulation = countriesInContinent.at(i).getPopulation();
			highestCountry = i;
		}
	}
	
	return highestCountry;
}

int Continent::getHighestGDPSpent() const {
	
	int highGDPSpent = countriesInContinent.at(0).getEducationGDPSpent();
	int highestCountry = 0;
	
	for(int i = 1; i < countriesInContinent.size(); ++i) {
		if(highGDPSpent < countriesInContinent.at(i).getEducationGDPSpent()) {
			highGDPSpent = countriesInContinent.at(i).getEducationGDPSpent();
			highestCountry = i;
		}
	}
	
	return highestCountry;
}

int Continent::getHighestLiteracyRate() const {
	
	int LiteracyRate = countriesInContinent.at(0).getLiteracyRate();
	int highestCountry = 0;
	
	for(int i = 1; i < countriesInContinent.size(); ++i) {
		if(LiteracyRate < countriesInContinent.at(i).getLiteracyRate()) {
			LiteracyRate = countriesInContinent.at(i).getLiteracyRate();
			highestCountry = i;
		}
	}
	
	return highestCountry;
}

void Continent::setName(string newName) {
	name = newName;
}

void Continent::setCountriesInContinent(Country newCountry) {
	countriesInContinent.push_back(newCountry);
}

void Continent::setHighestPopulation(Country newHighestPopulation) {
	highestPopulation = newHighestPopulation;
}

void Continent::setHighestGDPSpent(Country newHighestGDPSpent) {
	highestGDPSpent = newHighestGDPSpent;
}

void Continent::setHighestLiteracyRate(Country newHighestLiteracyRate) {
	highestLiteracyRate = newHighestLiteracyRate;
}

ostream& operator<<(ostream& os, const Continent& c) {
	
	os << c.getName() << "\n\tPopulation: " << c.getTotalPopulation()
	<< "\n\tCountry with highest literacy rate: " 
	<< c.getCountryInContinent(c.getHighestLiteracyRate()).getName()
	<< " with a population of " << c.getCountryInContinent(c.getHighestLiteracyRate()).getPopulation() 
	<< " and a literacy rate of " <<  c.getCountryInContinent(c.getHighestLiteracyRate()).getLiteracyRate() 
	<< "\n\tCountry with highest GDP spendature on education: " 
	<< c.getCountryInContinent(c.getHighestGDPSpent()).getName()
	<< " with a population of " << c.getCountryInContinent(c.getHighestGDPSpent()).getPopulation() 
	<< " and a literacy rate of " <<  c.getCountryInContinent(c.getHighestGDPSpent()).getLiteracyRate() 
	<< "\n\tCountry with highest population: " 
	<< c.getCountryInContinent(c.getHighestPopulation()).getName()
	<< " with a population of " << c.getCountryInContinent(c.getHighestPopulation()).getPopulation() 
	<< " and a literacy rate of " <<  c.getCountryInContinent(c.getHighestPopulation()).getLiteracyRate() 
	<< '\n';
	
	return os;
}