/*****************************************
** File:    driver.cpp
** Project: CSCE 221 Project 0, Spring 2019
** Author:  Eric Weiss
** Date:    1/23/19
** Section: 512
** E-mail:  ericweiss98@tamu.edu 
**
**   This file contains the main driver program for project 0
**This program reads the data from the 2 desired files then 
**outputs the desired information such as total and largest populations
**of each continent.
**
***********************************************/

#include "Country.h"
#include "Continent.h"
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>

using namespace std;

//reads from the files and inputs them into the desired vector
vector<Continent> readFromFiles(string file1, string file2) {
	
	//file 1 variables;
	string continent;
	string country;
	string extra;
	int countries;
	int contNum = -1;
	//used to collect data of what countries go in what continents
	vector<Continent> world1;
	//inputs the data into the countries, then countries into continents
	vector<Continent> world2;
	
	//file 2 variables
	bool firstLine = true;
	string populationStr;
	long population;
	string literacyRateStr;
	float literacyRate;
	string primaryCompFemStr;
	float primaryCompFem;
	string primaryCompMaleStr;
	float primaryCompMale;
	string primaryCompTotStr;
	float primaryCompTot;
	string educationGDPSpentStr;
	float educationGDPSpent;
	string youthLitRateFemStr;
	float youthLitRateFem;
	string youthLitRateMaleStr;
	float youthLitRateMale;	
	string line;
	int placeHolder;
	int placeHolder2;
	
	ifstream inFs;
	
	inFs.open(file1);
	
	//check if file is open
	if(!inFs.is_open()) {
		cout << "Error: Unable to open document" << endl;
	}
	else {
		
		//read until end of file
		while(!inFs.eof()) {
			
			//retrieve the continent names and input them in variables
			inFs >> continent >> extra >> countries;
			
			//gets the line with the continent so it doesn't mess up in the for loop
			getline(inFs, extra);
			
			world1.push_back(continent);
			
			//ups the index of where all the countries should go
			++contNum;
			world1.at(contNum).setName(continent);
			
			for(int i = 0; i < countries; ++i) {
				getline(inFs, country);
				
				//inputs country into continent vector within world1
				world1.at(contNum).setCountriesInContinent(country);
				}
			
		}
	}
	
	//closes file1
	inFs.close();
	
	//inputs continents into world2 vector
	for(int i = 0; i < world1.size(); ++i) {
		world2.push_back(world1.at(i).getName());
	}
	
	//opens file2
	inFs.open(file2);
	
	//checks if file2 is open
	if(!inFs.is_open()) {
		cout << "Error: Unable to open document" << endl;
	}
	else {
		
		//reads file2 until end of file
		while(!inFs.eof()) {
			//used to ignore first line of data that tells what data values mean
			if(firstLine == true) {
				getline(inFs, extra);
				firstLine = false;
			}
			//used for after first line
			else {
				
				//resets variables
				population = -1;
				literacyRate = -1;
				primaryCompFem = -1;
				primaryCompMale = -1;
				primaryCompTot = -1;
				educationGDPSpent = -1;
				youthLitRateFem = -1;
				youthLitRateMale = -1;	

				//gets data and separates them into different strings
				getline(inFs, line);
				istringstream ss(line);
				ss >> country >> populationStr >> literacyRateStr >> educationGDPSpentStr
				>> primaryCompTotStr >> primaryCompMaleStr >> primaryCompFemStr
				>> youthLitRateFemStr >> youthLitRateMaleStr;
				
				//creates a temporary country for the next value on the data list
				Country countryTmp;
				
				//resets variable
				string nameTmp = "";
				
				/*because originally only correctly compared to Venezuela if compared
				identically to world1, so I'm ony checking the first 4 letters of each */
				for(int i = 0; i < 4; ++i) {
					nameTmp += country.at(i);
				}
				/*because of multiple countries being similar these if-else if statements
				make sure that countries don't get repeated in getting put in the list */
				if(nameTmp == "Unit" || nameTmp == "Cent") {
					for(int i = 4; country.at(i) != '-'; ++i) {
						nameTmp += country.at(i);
						placeHolder = i + 1;
						placeHolder2 = placeHolder + 2;
					}
					for(int i = placeHolder; i < placeHolder2; ++i) {
						nameTmp += country.at(i);
					}
				}
				else if (nameTmp == "Mala") {
					nameTmp += country.at(4);
				}
				else if (nameTmp == "Kyrg") {
					nameTmp += country.at(6);
				}
				else if(nameTmp == "Domi" || nameTmp == "Guin") {
					if(country.length() > 9) {
						for(int i = 4; country.at(i) != '-'; ++i) {
							nameTmp += country.at(i);
						}
					}
				}
				
				//sets country name				
				countryTmp.setName(country);
				
				for(int i = 0; i < world1.size(); ++i) {
					for(int j = 0; j < world1.at(i).getCountriesInContinent(); ++j) {
						//resets origTmp
						string origTmp = "";
						//sets first 4 letters as origTmp
						for(int k = 0; k < 4; ++k) {
							origTmp += world1.at(i).getCountryInContinent(j).getName().at(k);
						}
						//does all of the same if else ifs as nameTmp
						if(origTmp == "Unit" || origTmp == "Cent") {
							for(int k = 4; world1.at(i).getCountryInContinent(j).getName().at(k) != '-'; ++k) {
								origTmp += world1.at(i).getCountryInContinent(j).getName().at(k);
								placeHolder = k + 1;
								placeHolder2 = placeHolder + 2;
							}
							for(int k = placeHolder; k < placeHolder2; ++k) {
								origTmp += world1.at(i).getCountryInContinent(j).getName().at(k);
							}
						}
						else if(origTmp == "Mala") {
							origTmp += world1.at(i).getCountryInContinent(j).getName().at(4);
						}
						else if(origTmp == "Kyrg") {
							origTmp += world1.at(i).getCountryInContinent(j).getName().at(6);
						}
						else if(origTmp == "Domi" || origTmp == "Guin") {
							if(world1.at(i).getCountryInContinent(j).getName().length() > 9) {
								for (int k = 4; world1.at(i).getCountryInContinent(j).getName().at(k) != '-'; ++k) {
									origTmp += world1.at(i).getCountryInContinent(j).getName().at(k);
								}
							}
						}
						//if the strings match all the data values are set & it is placed in world2
						if(origTmp == nameTmp) {
							//checks if the value is N/A & inputs data if not
							if(populationStr != "N/A") {
								population = stol(populationStr);
								countryTmp.setPopulation(population);
							}
							//checks if the value is N/A & inputs data if not
							if(literacyRateStr != "N/A") {
								literacyRate = stof(literacyRateStr);
								countryTmp.setLiteracyRate(literacyRate);
							}
							//checks if the value is N/A & inputs data if not
							if(educationGDPSpentStr != "N/A") {
								educationGDPSpent = stof(educationGDPSpentStr);
								countryTmp.setEducationGDPSpent(educationGDPSpent);
							}
							//checks if the value is N/A & inputs data if not
							if(primaryCompTotStr != "N/A") {
								primaryCompTot = stof(primaryCompTotStr);
								countryTmp.setPrimaryCompletionTotal(primaryCompTot);
							}
							//checks if the value is N/A & inputs data if not
							if(primaryCompMaleStr != "N/A") {
								primaryCompMale = stof(primaryCompMaleStr);
								countryTmp.setPrimaryCompletionMale(primaryCompMale);
							}
							//checks if the value is N/A & inputs data if not
							if(primaryCompFemStr != "N/A") {
								primaryCompFem = stof(primaryCompFemStr);
								countryTmp.setPrimaryCompletionFemale(primaryCompFem);
							}
							//checks if the value is N/A & inputs data if not
							if(youthLitRateFemStr != "N/A") {
								youthLitRateFem = stof(youthLitRateFemStr);
								countryTmp.setYouthLitRateFem(youthLitRateFem);
							}
							//checks if the value is N/A & inputs data if not
							if(youthLitRateMaleStr != "N/A") {
								youthLitRateMale = stof(youthLitRateMaleStr);
								countryTmp.setYouthLitRateMale(youthLitRateMale);
							}
							world2.at(i).setCountriesInContinent(countryTmp);
						}
					}
				}
				
			}
		}		
	}
	
	//closes file2
	inFs.close();
	
	//returns the world2 vector
	return world2;
}
	
int main() {
	
	//stores filenames
	string file1 = "CountriesContinents.txt";
	string file2 = "2013WorldBankEducationCensusData.txt";
	
	//calls function readFromFiles to set the world vector
	vector<Continent> world = readFromFiles(file1, file2);
	
	//outputs all data as desired for each continent
	for (int i = 0; i < world.size(); ++i) {
		cout << world.at(i);
	}
	
	return 0;
}