/*****************************************
** File:    Country.h
** Project: CSCE 221 Project 0, Spring 2019
** Author:  Eric Weiss
** Date:    1/23/19
** Section: 512
** E-mail:  ericweiss98@tamu.edu 
**
**   This file contains the Country class declaration
**
***********************************************/

#ifndef COUNTRY_H
#define COUNTRY_H

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Country  {
	public:
		//construct the class with no parameters
		Country();
		//construct the class with the name
		Country(string);
		//-------------------------------------------------------
		// Name: getName
		// PreCondition:  class exists
		// PostCondition: Returns the name of the country
		//---------------------------------------------------------
		string getName() const;
		//-------------------------------------------------------
		// Name: getPopulation
		// PreCondition:  class exists
		// PostCondition: Returns the population of the country
		//---------------------------------------------------------
		long getPopulation() const;
		//-------------------------------------------------------
		// Name: getLiteracyRate
		// PreCondition:  class exists
		// PostCondition: Returns the literacy rate of the country
		//---------------------------------------------------------
		float getLiteracyRate() const;
		//-------------------------------------------------------
		// Name: getPrimaryCompletionFemale
		// PreCondition:  class exists
		// PostCondition: Returns the Primary Completion Female variable of the country
		//---------------------------------------------------------
		float getPrimaryCompletionFemale() const;
		//-------------------------------------------------------
		// Name: getPrimaryCompletionMale
		// PreCondition:  class exists
		// PostCondition: Returns the Primary Completion Male variable of the country
		//---------------------------------------------------------
		float getPrimaryCompletionMale() const;
		//-------------------------------------------------------
		// Name: getPrimaryCompletionTotal
		// PreCondition:  class exists
		// PostCondition: Returns the Primary Completion Total variable of the country
		//---------------------------------------------------------
		float getPrimaryCompletionTotal() const;
		//-------------------------------------------------------
		// Name: getEducationGDPSpent
		// PreCondition:  class exists
		// PostCondition: Returns the GDP spent of the country
		//---------------------------------------------------------
		float getEducationGDPSpent() const;
		//-------------------------------------------------------
		// Name: getYouthLitRateFem
		// PreCondition:  class exists
		// PostCondition: Returns the Youth lit rate Female variable of the country
		//---------------------------------------------------------
		float getYouthLitRateFem() const;
		//-------------------------------------------------------
		// Name: getYouthLitRateMale
		// PreCondition:  class exists
		// PostCondition: Returns the Youth lit rate Male variable of the country
		//---------------------------------------------------------
		float getYouthLitRateMale() const;
		//-------------------------------------------------------
		// Name: setName
		// PreCondition:  class exists & new string given
		// PostCondition: changes the name of the country
		//---------------------------------------------------------
		void setName(string);
		//-------------------------------------------------------
		// Name: setPopulation
		// PreCondition:  class exists & new value given
		// PostCondition: changes the population of the country
		//---------------------------------------------------------
		void setPopulation(long);
		//-------------------------------------------------------
		// Name: setLiteracyRate
		// PreCondition:  class exists & new value given
		// PostCondition: changes the literacy rate of the country
		//---------------------------------------------------------
		void setLiteracyRate(float);
		//-------------------------------------------------------
		// Name: setPrimaryCompletionFemale
		// PreCondition:  class exists & new value given
		// PostCondition: changes the Primary Completion Female of the country
		//---------------------------------------------------------
		void setPrimaryCompletionFemale(float);
		//-------------------------------------------------------
		// Name: setPrimaryCompletionMale
		// PreCondition:  class exists & new value given
		// PostCondition: changes the Primary Completion Male of the country
		//---------------------------------------------------------
		void setPrimaryCompletionMale(float);
		//-------------------------------------------------------
		// Name: setPrimaryCompletionTotal
		// PreCondition:  class exists & new value given
		// PostCondition: changes the Primary Completion Total of the country
		//---------------------------------------------------------
		void setPrimaryCompletionTotal(float);
		//-------------------------------------------------------
		// Name: setEducationGDPSpent
		// PreCondition:  class exists & new value given
		// PostCondition: changes the GDP spent of the country
		//---------------------------------------------------------
		void setEducationGDPSpent(float);
		//-------------------------------------------------------
		// Name: setYouthLitRateFem
		// PreCondition:  class exists & new value given
		// PostCondition: changes the youth lit rate Female of the country
		//---------------------------------------------------------
		void setYouthLitRateFem(float);
		//-------------------------------------------------------
		// Name: setYouthLitRateMale
		// PreCondition:  class exists & new value given
		// PostCondition: changes the youth lit rate Male of the country
		//---------------------------------------------------------
		void setYouthLitRateMale(float);
	
	private:
		string name;
		long population = -1;
		float literacyRate = -1;
		float primaryCompletionFemale = -1;
		float primaryCompletionMale = -1;
		float primaryCompletionTotal = -1;
		float educationGDPSpent = -1;
		float youthLitRateFem = -1;
		float youthLitRateMale = -1;		
	
};

#endif