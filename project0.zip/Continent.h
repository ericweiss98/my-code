/*****************************************
** File:    Continent.h
** Project: CSCE 221 Project 0, Spring 2019
** Author:  Eric Weiss
** Date:    1/23/19
** Section: 512
** E-mail:  ericweiss98@tamu.edu 
**
**   This file contains the Continent class declaration
**
***********************************************/

#ifndef CONTINENT_H
#define CONTINENT_H

#include "Country.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Continent {//: public Country {
	public:
		//construct class with the continent's name
		Continent(string);
		//-------------------------------------------------------
		// Name: getName
		// PreCondition:  class exists
		// PostCondition: Returns the name of the continent
		//---------------------------------------------------------
		string getName() const;
		//-------------------------------------------------------
		// Name: getCountriesInContinent
		// PreCondition:  class exists with countries in its vecotr
		// PostCondition: Returns the index of the vector for the desired country
		//---------------------------------------------------------
		int getCountriesInContinent() const;
		//-------------------------------------------------------
		// Name: getTotalPopulation
		// PreCondition:  class exists
		// PostCondition: Returns the total population of the countries combined in the continent
		//---------------------------------------------------------
		long getTotalPopulation() const;
		//-------------------------------------------------------
		// Name: getCountryInContinent
		// PreCondition:  class exists with an int no more than the size of the countriesInContinent vector
		// PostCondition: Returns the index of the desired country
		//---------------------------------------------------------
		Country getCountryInContinent(int) const;
		//-------------------------------------------------------
		// Name: getHighestPopulation
		// PreCondition:  class exists with at least 1 country
		// PostCondition: Returns the index of the country with the highest population in the continent
		//---------------------------------------------------------
		int getHighestPopulation() const;
		//-------------------------------------------------------
		// Name: getHighestGDPSpent
		// PreCondition:  class exists with at least 1 country
		// PostCondition: Returns the index of the country with the highest GDP spent in the continent
		//---------------------------------------------------------
		int getHighestGDPSpent() const;
		//-------------------------------------------------------
		// Name: getHighestLiteracyRate
		// PreCondition:  class exists with at least 1 country
		// PostCondition: Returns the index of the country with the highest literacy rate in the continent
		//---------------------------------------------------------
		int getHighestLiteracyRate() const;
		//-------------------------------------------------------
		// Name: setName
		// PreCondition:  class exists
		// PostCondition: Sets the name of the continent
		//---------------------------------------------------------
		void setName(string);
		//-------------------------------------------------------
		// Name: setCountriesInContinent
		// PreCondition:  class exists
		// PostCondition: Adds a country to the vector
		//---------------------------------------------------------
		void setCountriesInContinent(Country);
		//-------------------------------------------------------
		// Name: setHighestPopulation
		// PreCondition:  class exists with given country in vector
		// PostCondition: sets the highest population as the desired country
		//---------------------------------------------------------
		void setHighestPopulation(Country);
		//-------------------------------------------------------
		// Name: setHighestGDPSpent
		// PreCondition:  class exists with given country in vector
		// PostCondition: sets the highest GDP spent as the desired country
		//---------------------------------------------------------
		void setHighestGDPSpent(Country);
		//-------------------------------------------------------
		// Name: setHighestLiteracyRate
		// PreCondition:  class exists with given country in vector
		// PostCondition: sets the highest literacy rate as the desired country
		//---------------------------------------------------------
		void setHighestLiteracyRate(Country);

	private:
		string name;
		vector<Country> countriesInContinent;
		Country highestPopulation;
		Country highestGDPSpent;
		Country highestLiteracyRate;
};

//overloads << operator to have it output desired data
ostream& operator<<(ostream& os, const Continent& c);

#endif