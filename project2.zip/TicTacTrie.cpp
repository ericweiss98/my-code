#include "TicTacTrie.h"
#include "TicTacToe.h"
#include "TicTacNode.h"
#include <iostream>
#include <string>
#include <map>

using namespace std;

TicTacTrie::TicTacTrie() {
	head = nullptr;
}

int TicTacTrie::getM_xWins() {
	return m_xWins;
}
	
int TicTacTrie::getM_oWins() {
	return m_oWins;	
}
	
int TicTacTrie::getM_draws() {
	return m_draws;
}
	
int TicTacTrie::getM_size() {
		
	return m_size;
}
	
void TicTacTrie::getStats() {
	//returns all of the desired stat outputs
	cout << "Final Trie Statistics\n"
		 << "======================\n"
		 << "Player X Wins:\t" << m_xWins << '\n'
		 << "Player O Wins:\t" << m_oWins << '\n'
		 << "Draws:\t" << m_draws << '\n'
		 << "Trie Size: \t" << m_size << '\n';
}
	
void TicTacTrie::addGame(TicTacToe game) {
	
	//sets all the variables
	TicTacNode* trie = head;
	TicTacNode* tic = game.getHead();
	
	int trieChildSize;
	int ticChildSize = tic->getChildSize();
	bool endLoop = false;

	//sets the trie equal to the first game inputted
	if (head == nullptr) {
		head = tic;
		trie = head;
		m_size +=1;
	}
	//if there is already a game
	else {
		//traverses trie until the end of the game being inputted
		while (ticChildSize != 0) {
			trieChildSize = trie->getChildSize();
			//checks all the children
			for (int i = 0; i < trieChildSize; ++i) {
				//moves down if nodes are same
				if (trie->m_children.at(i)->getWholeBoard() == tic->m_children.at(0)->getWholeBoard()) {
					trie = trie->m_children.at(i);
					tic = tic->m_children.at(0);
				}
				//sets children if no child nodes are same
				else if (i == trieChildSize - 1) {
					tic = tic->m_children.at(0);
					trie->setChild(tic);
					trie = trie->m_children.at(trie->getChildSize() - 1);
					//adds the new child to the size
					m_size += 1;
					endLoop = true;
				}
			}
			//ends the loop if the game was inputted
			ticChildSize = tic->getChildSize();
			if (endLoop == true) {
				break;
			}
		}
	}
	
	//add size of nodes after the inputted one
	while (ticChildSize != 0) {
		m_size += 1;
		tic = tic->m_children.at(tic->getChildSize() - 1);
		ticChildSize = tic->getChildSize();
	}
	
	//get final node and set TicTacToe vars
	string gameEnd = game.getEnd();
	game.setM_results(gameEnd);
	game.setM_isOver();
	
	//get results and edit vars	and output game results
	int result = game.getM_results();
	if (result == 0) {
		cout << "game did not end\n";
	}
	else if (result == 1) {
		cout << "Player X wins!\n";
		m_xWins += 1;
	}
	else if (result == 2) {
		cout << "Player O wins!\n";
		m_oWins += 1;
	}
	else if (result == 3) {
		cout << "The game was a draw!\n";
		m_draws += 1;
	}
	
	cout << "game Board: \n";
	
	//output game board
	for (int i = 0; i < 9; ++i) {
		cout << gameEnd.at(i);
		if (i == 2 || i == 5 || i == 8) {
			cout << '\n';
		}
	}
	cout << '\n';
}