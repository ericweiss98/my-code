#include "TicTacToe.h"
#include "TicTacNode.h"
#include <iostream>
#include <string>
#include <map>
#include<fstream>

using namespace std;

TicTacToe::TicTacToe() {
	//set defafult values
	m_isOver = false;
	m_results = 0;
	head = nullptr;
}
	
void TicTacToe::setM_isOver() {
	//0 in results means game did not end, therefor 0 sets isOver to false
	if (m_results != 0) {
		m_isOver = true;
	}
	else {
		m_isOver = false;
	}
}

void TicTacToe::setM_results(string game) {
	//if there are no '-', then game is set to draw
	int i = 0;
	while (game.at(i) != '-') {
		if (i == 8) {
			m_results = 3;
			break;
		}
		++i;
	}
	//changes result based on where the win was made if there was a win
	//top
	if ((game.at(0) == game.at(1)) && (game.at(0) == game.at(2))) {
		if (game.at(0) == 'X') {
			m_results = 1;
		}
		else if (game.at(0) == 'O') {
			m_results = 2;
		}
	}
	//middle row
	else if ((game.at(3) == game.at(4)) && (game.at(3) == game.at(5))) {
		if (game.at(3) == 'X') {
			m_results = 1;
		}
		else if (game.at(3) == 'O') {
			m_results = 2;
		}
	}
	//bottom
	else if ((game.at(6) == game.at(7)) && (game.at(6) == game.at(8))) {
		if (game.at(6) == 'X') {
			m_results = 1;
		}
		else if (game.at(6) == 'O') {
			m_results = 2;
		}
	}
	//left
	else if ((game.at(0) == game.at(3)) && (game.at(6) == game.at(0))) {
		if (game.at(0) == 'X') {
			m_results = 1;
		}
		else if (game.at(0) == 'O') {
			m_results = 2;
		}
	}
	//middle column
	else if ((game.at(1) == game.at(7)) && (game.at(4) == game.at(1))) {
		if (game.at(1) == 'X') {
			m_results = 1;
		}
		else if (game.at(1) == 'O') {
			m_results = 2;
		}
	}
	//right
	else if ((game.at(8) == game.at(2)) && (game.at(5) == game.at(8))) {
		if (game.at(2) == 'X') {
			m_results = 1;
		}
		else if (game.at(2) == 'O') {
			m_results = 2;
		}
	}
	//top left to bottom right
	else if ((game.at(0) == game.at(4)) && (game.at(0) == game.at(8))) {
		if (game.at(0) == 'X') {
			m_results = 1;
		}
		else if (game.at(0) == 'O') {
			m_results = 2;
		}
	}
	//top right to bottom left
	else if ((game.at(2) == game.at(4)) && (game.at(2) == game.at(6))) {
		if (game.at(2) == 'X') {
			m_results = 1;
		}
		else if (game.at(2) == 'O') {
			m_results = 2;
		}
	}
}
	
bool TicTacToe::getM_isOver() {
	return m_isOver;
}
	
int TicTacToe::getM_results() {
	return m_results;
}

string TicTacToe::getEnd() {
	
	//gets the head and starts child size	
	TicTacNode* n = head;
	int childSize = n->getChildSize();
	string game;
	//go to final node
	while (childSize != 0) {
		n = n->m_children.at(0);
		childSize = n->getChildSize();
	}
	//input board into string
	for (int i = 0; i < 9; ++i) {
		game += n->getBoard(i);
	}
	return game;
}
	
TicTacNode* TicTacToe::getHead() const {
	//finds head
	return head;
}
	
void TicTacToe::readGame(string filename) {
	
	string game = "";
	string gameMove;
	
	//open the file and read it
	ifstream inFs;
	
	inFs.open(filename);
	
	if(!inFs.is_open()) {
		cout << "Error: Unable to open " << filename << endl;
	}
	else {
		//gets the game as a string
		while(!inFs.eof()) {
			inFs >> gameMove;
			game += gameMove;
		}
	}
	
	string gameNode;
	int counter;
	
	TicTacNode* n = new TicTacNode();
	head = n;
	
	//read the game on board move at a time
	for (int i = 0; i < game.length(); i = i + 9) {
		
		TicTacNode* n2 = new TicTacNode();
		
		//resets the gameNode and counter
		gameNode = "";
		
		counter = 0;
		
		//read a single game
		for (int j = i; counter < 9; ++j) {
			
			gameNode += game.at(j);
			
			++counter;
		}
		
		//sets the first node
		if (gameNode == "---------") {
			n->setBoard(gameNode);
		}
		
		//set the game into the node then move into the child
		n2->setBoard(gameNode);
		
		//sets the child, then moves to child
		if ((i - 9 != game.length() - 1) && i != 0) {
			n->setChild(n2);
			n = n->m_children.at(0);
		}
	}	
	
	//outputs the file being read
	cout << "======================\n"
		 << "Reading: " << filename << '\n'
		 << "======================\n";
	
}