/**************************************************************
 * File:    TicTacNode.h
 * Project: CSCE 221 - Project 2
 * Author : Eric Weiss
 * Date   : 2/27/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * TicTacNode Class definition.
 *
 *************************************************************/
#ifndef TICTACNODE_H
#define TICTACNODE_H
#include <string>
#include <iostream>
#include <vector>
#include <map>

using namespace std;

class TicTacNode {
public:
    /**********************************************************************
     * Name: TicTacNode (Constructor)
     * PreCondition: Null value  
     * 
     * PostCondition:  create node
     *********************************************************************/
    TicTacNode();
	
    /**********************************************************************
     * Name: setBoard
     * PreCondition: game inputted  
     * 
     * PostCondition:  create board
     *********************************************************************/
    void setBoard(string);
	
    /**********************************************************************
     * Name: getBoard
     * PreCondition: original board exists and given an index
     * 
     * PostCondition:  return index
     *********************************************************************/
    char getBoard(int) const;
	
    /**********************************************************************
     * Name: getWholeBoard
     * PreCondition: original board exists
     * 
     * PostCondition:  return board as string
     *********************************************************************/
    string getWholeBoard() const;
	
    /**********************************************************************
     * Name: getChildSize
     * PreCondition: none
     * 
     * PostCondition:  return size of vector
     *********************************************************************/
	int getChildSize();
	
    /**********************************************************************
     * Name: setChildSize
     * PreCondition: given node
     * 
     * PostCondition:  sets child in vector
     *********************************************************************/
	void setChild(TicTacNode*);

    /**********************************************************************
     * Name: getChildSize
     * PreCondition: index needed
     * 
     * PostCondition:  return child at index
     *********************************************************************/
	TicTacNode* getChild(int);
	
    /**********************************************************************
     * Name: = overloader
     * PreCondition: assign node with desired second node  
     * 
     * PostCondition:  create duplicate node
     *********************************************************************/
	TicTacNode& operator=(const TicTacNode& other);
	
    /**********************************************************************
     * Name: == overloader
     * PreCondition: 2 nodes are given 
     * 
     * PostCondition:  tells if 2 nodes are equal 
     *********************************************************************/
	bool operator==(const TicTacNode& other);
	
	//allows other classes to move within it
	vector<TicTacNode*> m_children;

private:
	map<int,char> m_board;
    
};

    /**********************************************************************
     * Name: << overloader
     * PreCondition: gives a node
     * 
     * PostCondition:  outputs node as desired
     *********************************************************************/
ostream& operator<<(ostream& os, const TicTacNode& ll);

#endif