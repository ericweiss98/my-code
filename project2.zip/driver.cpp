#include "TicTacTrie.h"
#include "TicTacToe.h"
#include "TicTacNode.h"
#include <iostream>
#include<fstream>
using namespace std;

int main(int argc, char** argv) {
	
	string game;
	string filename = argv[1];
	TicTacTrie* trie = new TicTacTrie;
	
	//read game
	ifstream inFs;
	
	inFs.open(filename);
	
	if(!inFs.is_open()) {
		cout << "Error: Unable to open " << filename << endl;
	}
	else {
		while(!inFs.eof()) {
			//create tictactoe game and input it into trie
			TicTacToe n;
			inFs >> game;
			n.readGame(game);
			trie->addGame(n);
		}
		trie->getStats();
	}

	return 0;
}
