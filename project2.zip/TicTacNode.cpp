#include "TicTacNode.h"
#include <iostream>
#include <string>
#include <vector>
#include <map>

using namespace std;

TicTacNode::TicTacNode() {
}

void TicTacNode::setBoard(string game) {
	//set the board
	for (int i = 0; i < 9; ++i) {
		m_board[i] = game.at(i);
	}
}

char TicTacNode::getBoard(int index) const {
	return m_board.find(index)->second;
}

string TicTacNode::getWholeBoard() const {
	//returns the whole board as a string
	string board;
	for (int i = 0; i < 9; ++i) {
		board += m_board.find(i)->second;
	}
	return board;
}

int TicTacNode::getChildSize() {
	return m_children.size();
}

void TicTacNode::setChild(TicTacNode* child) {
	//set a new pointer in the children vector	
	m_children.push_back(child);
}
	
TicTacNode* TicTacNode::getChild(int index) {
	return m_children.at(index);
}
	
TicTacNode& TicTacNode::operator=(const TicTacNode& other) {
	//find the child size of the old node	
	int oldChildSize = this->getChildSize();
	//set the children and boards
	for (int i = 0; i < oldChildSize; ++i) {
		m_children.push_back(this->getChild(i));
	}
	for (int i = 0; i < 9; ++i) {
		m_board[i] = this->getBoard(i);
	}
}
	
bool TicTacNode::operator==(const TicTacNode& other) {
	//makes sure that each value of the board is equal
	for (int i = 0; i < 9; ++i) {
		if (m_board.find(i)->second != this->getBoard(i)) {
			return false;
		}
	}
	
	return true;
}

ostream& operator<<(ostream& os, const TicTacNode& ll) {
	//outputs the node's board
	os  << ll.getBoard(0) << ll.getBoard(1) << ll.getBoard(2) << '\n'
		<< ll.getBoard(3) << ll.getBoard(4) << ll.getBoard(5) << '\n'
		<< ll.getBoard(6) << ll.getBoard(7) << ll.getBoard(8) << '\n';
		
	return os;
}