/**************************************************************
 * File:    TicTacTrie.h
 * Project: CSCE 221 - Project 2
 * Author : Eric Weiss
 * Date   : 2/27/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * TicTacTrie Class definition.
 *
 *************************************************************/
#ifndef TICTACTRIE_H
#define TICTACTRIE_H
#include "TicTacToe.h"
#include "TicTacNode.h"
#include <string>
#include <iostream>
#include <map>

using namespace std;

class TicTacTrie {
public:
    /**********************************************************************
     * Name: TicTacTrie (Constructor)
     * PreCondition: Null value  
     * 
     * PostCondition:  create node
     *********************************************************************/
    TicTacTrie();
	
    /**********************************************************************
     * Name: getM_xWins
     * PreCondition: none
     * 
     * PostCondition:  returns m_xWins variable
     *********************************************************************/
	int getM_xWins();
	
    /**********************************************************************
     * Name: getM_oWins
     * PreCondition: none
     * 
     * PostCondition:  returns m_oWins variable
     *********************************************************************/
	int getM_oWins();
	
    /**********************************************************************
     * Name: getM_draws
     * PreCondition: none
     * 
     * PostCondition:  returns m_draws variable
     *********************************************************************/
	int getM_draws();
	
    /**********************************************************************
     * Name: getM_size
     * PreCondition: none
     * 
     * PostCondition:  returns m_size variable
     *********************************************************************/
	int getM_size();
	
    /**********************************************************************
     * Name: getStats
     * PreCondition: the trie has been made
     * 
     * PostCondition:  outputs final stats
     *********************************************************************/
	void getStats();
	
    /**********************************************************************
     * Name: addGame
     * PreCondition: there is a game to input
     * 
     * PostCondition:  adds the game
     *********************************************************************/
	void addGame(TicTacToe);

private:
	int m_xWins = 0;
	int m_oWins = 0;
	int m_draws = 0;
	int m_size = 0;
	TicTacNode* head;
    
};

#endif