/**************************************************************
 * File:    TicTacToe.h
 * Project: CSCE 221 - Project 2
 * Author : Eric Weiss
 * Date   : 2/27/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * TicTacToe Class definition.
 *
 *************************************************************/
#ifndef TICTACTOE_H
#define TICTACTOE_H
#include "TicTacNode.h"
#include <string>
#include <iostream>
#include <map>

using namespace std;

class TicTacToe {
public:
    /**********************************************************************
     * Name: TicTacToe (Constructor)
     * PreCondition: Null value  
     * 
     * PostCondition:  create node
     *********************************************************************/
    TicTacToe();

    /**********************************************************************
     * Name: setM_isOver
     * PreCondition: m_results has a value
     * 
     * PostCondition:  sets m_isOver
     *********************************************************************/
	void setM_isOver();
	
    /**********************************************************************
     * Name: setM_results
     * PreCondition: game is already inputted
     * 
     * PostCondition:  sets m_results
     *********************************************************************/
	void setM_results(string);
	
    /**********************************************************************
     * Name: getM_isOver
     * PreCondition: none
     * 
     * PostCondition:  returns m_isOver variable
     *********************************************************************/
	bool getM_isOver();
	
    /**********************************************************************
     * Name: getM_results
     * PreCondition: none
     * 
     * PostCondition:  returns m_results variable
     *********************************************************************/
	int getM_results();
	
    /**********************************************************************
     * Name: readGame
     * PreCondition: a string to read a file for is inputted
     * 
     * PostCondition:  creates the game
     *********************************************************************/
	void readGame(string);
	
    /**********************************************************************
     * Name: getEnd
     * PreCondition: TicTacToe board made
     * 
     * PostCondition:  outputs end of the game
     *********************************************************************/
	string getEnd();
	
    /**********************************************************************
     * Name: getHead
     * PreCondition: head exists
     * 
     * PostCondition:  returns head
     *********************************************************************/
	TicTacNode* getHead() const;
	
private:
	bool m_isOver;
	int m_results;
	TicTacNode* head;
    
};

#endif