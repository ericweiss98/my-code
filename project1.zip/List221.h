/**************************************************************
 * File:    List221.h
 * Project: CSCE 221 - Project 1
 * Author : Eric Weiss
 * Date   : 2/12/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * List221 Class definition.
 *
 *************************************************************/
#ifndef LIST221_H
#define LIST221_H
#include <string>
#include "Node221.h"

template <class T>
class List221 {
public:
    /**********************************************************************
    * Name: List221 (Constructor)
    * PreCondition: No list  
    * 
    * PostCondition:  New list
    *********************************************************************/
    List221();

    /**********************************************************************
    * Name: List221 (Constructor)
    * PreCondition: No list and 1 parameter of data  
    * 
    * PostCondition:  creates a linked list with a node
    *********************************************************************/
    List221(T data);
    
    /**********************************************************************
    * Name: List221 (Copy Constructor)
    * PreCondition: A list already exists  
    * 
    * PostCondition:  creates a 2nd list same as first
    *********************************************************************/
	List221(const List221& other);
	
    /**********************************************************************
    * Name: List221 (Destructor)
    * PreCondition: list exists
    * 
    * PostCondition:  List is gone
    *********************************************************************/
	~List221();
	 
    /**********************************************************************
    * Name: Size
    * PreCondition: None
    * 
    * PostCondition:  Output list size
    *********************************************************************/
	virtual int  Size() const = 0;
	
    /**********************************************************************
    * Name: Empty
    * PreCondition: None
    * 
    * PostCondition:  Outputs if list is empty
    *********************************************************************/
	virtual bool Empty() const = 0; 
	
	/**********************************************************************
    * Name: Push
    * PreCondition: List exists
    * 
    * PostCondition:  Adds element to end of list
    *********************************************************************/
	virtual bool Push(T obj) = 0;	
	
	/**********************************************************************
    * Name: Pop
    * PreCondition: List exists with at least 1 element
    * 
    * PostCondition:  Removes element from end of list
    *********************************************************************/
	virtual bool Pop() = 0;	
	
	/**********************************************************************
    * Name: Clear
    * PreCondition: List exists
    * 
    * PostCondition:  Clears list
    *********************************************************************/
	virtual bool Clear() = 0;
	
protected:
    Node221<T>* head;
	Node221<T>* tail;
};

#include "List221.cpp"
#endif