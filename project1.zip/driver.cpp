/**************************************************************
 * File:    Driver.cpp
 * Project: CSCE 221 - Project 1
 * Author : Eric Weiss
 * Date   : 2/12/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * Sample driver file for project 1.
 *
 *************************************************************/
#include "List221.h"
#include "Stack221.h"
#include "Queue221.h"
#include "Exceptions221.h"
#include "Node221.h"
#include <iostream>

int main(int argc, char *argv[]) {

    Stack221<int> *myStack = new Stack221<int>();
    Queue221<int> myQueue;
    
    
    try {
        for (int i = 0; i < 10;){
			cout << "Queue Empty: " << myQueue.Empty() << endl;
			cout << "Stack Empty: " << myStack->Empty() << endl;
            myStack->Push(i);
            myQueue.Push(i++);
			cout << "Top of stack: " << myStack->Top() << endl;
			cout << "Front of Queue: " << myQueue.Front() << endl;
			cout << "Back of Queue: " << myQueue.Back() << endl;
        }
		
	Stack221<int> *myStack2(myStack);
    cout << "Queue size: " << myQueue.Size() << endl;
    cout << "Stack size: " << myStack->Size() << endl;
    cout << "Stack2 size: " << myStack2->Size() << endl;
	cout << "Queue pop: " << myQueue.Pop() << endl;
	cout << "Stack pop: " << myStack->Pop() << endl;
    cout << "Queue size: " << myQueue.Size() << endl;
    cout << "Stack size: " << myStack->Size() << endl;
    cout << "Stack2 size: " << myStack->Size() << endl;
	cout << "Back of Queue: " << myQueue.Back() << endl;
	cout << "Top of stack: " << myStack->Top() << endl;
	cout << "Top of stack2: " << myStack2->Top() << endl;
    cout << "Queue cleared = " << myQueue.Clear() << endl;
    cout << "Stack cleared = " << myStack->Clear() << endl;
    cout << "Stack2 cleared = " << myStack2->Clear() << endl;
    
    }
    catch (Exceptions221 &E){
        cout << "Exception: " << E.GetMessage() << endl;
    }
    
    delete myStack;
}