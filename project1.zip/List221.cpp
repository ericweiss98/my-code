#ifndef LIST221_CPP
#define LIST221_CPP

#include "List221.h"

using namespace std;

template <class T>
List221<T>::List221() 
{
	//sets head and tail no null if no nodes in list
	head = nullptr;
	tail = nullptr;
}

template <class T>
List221<T>::List221(T data) 
{
	//make the new nodes
    Node221<T>* n = new Node221<T>;
    Node221<T>* end = new Node221<T>;
	
	//store given data in n's data
    n->data = data;
	
	//checks if head does not currently exist
    if (head == nullptr)
    {
		//sets head, and makes end the head for the last node val
        head = n;
        end = head;
		//makes sure tail is nullptr before setting tail as the end
		if(end->next == nullptr) {
			tail = end;
		}
    }
}

template <class T>
List221<T>::~List221() 
{
	Node221<T>* nxt = nullptr;
	
	//continues while head exists
	while (head) {
		//sets a link to the next value to make head equal to after it's deleted
		nxt = head->next;
		delete head;
		head = nxt;
	}
	//finish by making head a nullptr
	head = nullptr;
}

template <class T>
List221<T>::List221(const List221& other) 
{
	//create extra nodes
    Node221<T>* cur = other.head;
    int numVals = 0;
	Node221<T>* valCount = other.head;
    Node221<T>* end = nullptr;
    Node221<T>* prv = nullptr;

	//finds the value in the given list
	while (valCount != nullptr) {
		numVals++;
		valCount = valCount->next;
	}
	
	//adds the same amount to new list as given
    for(int q = 0; q < numVals; q++)
    {
        Node221<T>* n = new Node221<T>;
		
		//input the data of the node in the same position into the new node
        n->data = cur->data;
		
		//creates the head and tail if they are nullptrs
        if (head == nullptr)
        {
            head = n;
            end = head;
			if(end->next == nullptr) {
				tail = end;
			}
        }
        else
        {
			//set the next value and end to n
            end->next = n;
            end = n;
			if(end->next == nullptr) {
				tail = end;
			}
        }
		
		//sets the prev value of n to what is before it
        n->prev=prv;
        prv=n;
		//incriment cur to have next value in next iteration
        cur = cur->next;
    }
    end->next = nullptr;
}

template class List221<int>;

#endif