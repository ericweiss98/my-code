#ifndef STACK_CPP
#define STACK_CPP

#include <iostream>
#include "List221.h"
#include "Stack221.h"
#include "Queue221.h"

using namespace std;

template <class T>
Stack221<T>::Stack221() {
	
	//set the top node to null
	head = nullptr;
	
}
	
template <class T>
Stack221<T>::Stack221(const Stack221& other) 
{
	Node221<T>* cur = other.head;
	Queue221<T> Copy;
	
	//set the data into a Queue
	for (int i = 0; i < other.Size(); ++i) {
		Copy.Push(cur->data);
		cur = cur->next;
	}
	
	//set up nodes to traverse queue
	Node221<T>* cur2 = new Node221<T>;
	cur2->data = Copy.Back();
	Node221<T>* finish = head;
	
	while (cur2) {
		//traverse queue and dump it into stack
		finish->next = head;
		head->data = top;
		head = finish;
		top = head->data;
		cur2 = cur2->next;
		finish->data = cur2->data;
	}
	
}
	
template <class T>
Stack221<T>::~Stack221() {
	
	Node221<T>* nxt = nullptr;
	//while there is a head delete the head then make it the next node
	while (head) {
		nxt = head->next;
		delete head;
		head = nxt;
	}
	//make head NULL
	head = nullptr;
}

template <class T>
T Stack221<T>::Top() {
	//returns top
	return top;
}

template <class T>
int  Stack221<T>::Size() const
{
	int numVals = 0;
	Node221<T>* valCount = head;
		
	//traverses stack until an end is reached to find size
	while (valCount != nullptr) {
		numVals++;
		valCount = valCount->next;
	}
	return numVals;
}

template <class T>
bool Stack221<T>::Empty() const
{
	//if the head is a nullptr the stack is empty
	if (head == nullptr) {
		return true;
	}
	else {
		return false;
	}
}

template <class T>
bool Stack221<T>::Push(T obj)
{
	//put the data into a new node
	Node221<T>* n = new Node221<T>;
	n->data = obj;

	//add the node to the top of the stack
	n->next = head;
	head = n;
	top = head->data;
	
	return 1;
	
}

template <class T>
bool Stack221<T>::Pop()
{
    Node221<T>* cur = head;

	//delete the head and make the following value head
	cur = cur->next;
	delete head;
	head = cur;
	top = head->data;
	
	return 1;

}

template <class T>
bool Stack221<T>::Clear()
{
	Node221<T>* nxt = nullptr;
	//while there is a head delete the head then make it the next node
	while (head) {
		nxt = head->next;
		delete head;
		head = nxt;
	}
	
	head = nullptr;
	//make head NULL
	return 1;
}

template class Stack221<int>;

#endif