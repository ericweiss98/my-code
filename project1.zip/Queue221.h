/**************************************************************
 * File:    Queue221.h
 * Project: CSCE 221 - Project 1
 * Author : Eric Weiss
 * Date   : 2/12/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * Queue221 Class definition.
 *
 *************************************************************/
#ifndef QUEUE221_H
#define QUEUE221_H
#include "List221.h"
#include <string>

template <class T>
class Queue221 : public List221<T>{
public:
    /**********************************************************************
     * Name: Queue221 (Constructor)
     * PreCondition: No paramater given  
     * 
     * PostCondition:  Error object
     *********************************************************************/
    Queue221();
	
    /**********************************************************************
     * Name: Queue221 (Destructor)
     * PreCondition: No paramater given  
     * 
     * PostCondition:  Error object
     *********************************************************************/
    ~Queue221();

    /**********************************************************************
     * Name: Front
     * PreCondition: Front points to something.  
     * 
     * PostCondition:  Returns front value.
     *********************************************************************/
    T Front() const;
	
    /**********************************************************************
     * Name: Front
     * PreCondition: Back points to something.  
     * 
     * PostCondition:  Returns back value.
     *********************************************************************/
	T Back() const;

    /**********************************************************************
    * Name: Size
    * PreCondition: None
    * 
    * PostCondition:  Output Queue size
    *********************************************************************/
	int  Size() const;
	
    /**********************************************************************
    * Name: Empty
    * PreCondition: None
    * 
    * PostCondition:  Outputs if list is empty
    *********************************************************************/
	bool Empty() const; 
	
	/**********************************************************************
    * Name: Push
    * PreCondition: List exists
    * 
    * PostCondition:  Adds element to end of list
    *********************************************************************/
	bool Push(T obj);	
	
	/**********************************************************************
    * Name: Pop
    * PreCondition: List exists with at least 1 element
    * 
    * PostCondition:  Removes element from end of list
    *********************************************************************/
	bool Pop();	
	
	/**********************************************************************
    * Name: Clear
    * PreCondition: List exists
    * 
    * PostCondition:  Clears list
    *********************************************************************/
	bool Clear();

private:
	Node221<T>* head;
	Node221<T>* tail;

};

#include "Queue221.cpp"
#endif