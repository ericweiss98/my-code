/**************************************************************
 * File:    Node221.h
 * Project: CSCE 221 - Project 1
 * Author : Eric Weiss
 * Date   : 2/12/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * Node221 Class definition.
 *
 *************************************************************/
#ifndef NODE221_H
#define NODE221_H
#include <string>
#include <iostream>
using namespace std;

template <class T>
class Node221 {
public:
    /**********************************************************************
     * Name: Node221 (Constructor)
     * PreCondition: Null value  
     * 
     * PostCondition:  create node
     *********************************************************************/
    Node221();

    /**********************************************************************
     * Name: Node221 (Constructor)
     * PreCondition: includes data val
     * 
     * PostCondition:  create node
     *********************************************************************/
    Node221(T data);
	
    /**********************************************************************
     * Name: Node221 (Destructor)
     * PreCondition: Node exists
     * 
     * PostCondition:  Node is gone
     *********************************************************************/
	virtual ~Node221() {}
    
//private:
    
	T data;
	Node221<T>* next;
	Node221<T>* prev;
	
};

#include "Node221.cpp"

#endif