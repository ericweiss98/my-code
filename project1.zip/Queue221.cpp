#ifndef QUEUE221_CPP
#define QUEUE221_CPP

#include "List221.h"
#include "Queue221.h"
#include "Node221.h"

#include <iostream>


template <class T>
Queue221<T>::Queue221() {
	
	//set empty Queue head & tail to nullptr
	head = nullptr;
	tail = nullptr;
	
}

template <class T>
Queue221<T>::~Queue221() {
	
	Node221<T>* nxt = nullptr;
	//while head exists delete head then set it to the next value in the Queue
	while (head) {
		nxt = head->next;
		delete head;
		head = nxt;
	}
	//set head to NULL
	head = nullptr;
}

template <class T>
T Queue221<T>::Front() const {
	//returns value in head
	return head->data;
}

template <class T>	
T Queue221<T>::Back() const {
	//returns value in tail
	return tail->data;
}

template <class T>
int  Queue221<T>::Size() const
{
	int numVals = 0;
	Node221<T>* valCount = head;
	
	//checks how many iterations are made until end of Queue is reached
	while (valCount != nullptr) {
		numVals++;
		valCount = valCount->next;
	}
	return numVals;
}

template <class T>
bool Queue221<T>::Empty() const
{
	//Queue is empty if both head and tail are nullptr
	if (head == nullptr && tail == nullptr) {
		return true;
	}
	else {
		return false;
	}
}

template <class T>
bool Queue221<T>::Push(T obj)
{
	
	Node221<T>* cur = tail;
	Node221<T>* n = new Node221<T>;
	n->data = obj;
	
	//if head == nullptr the list is empty, thus needs to be made
    if (head == nullptr)
    {
        head = n;
        cur = head;
		if(cur->next == nullptr) {
			tail = cur;
		}
    }
	else {
		//makes the node after tail n, then sets the tail as that new last node
		tail->next = n;
		tail = tail->next;
	}
	
	return 1;
}

template <class T>
bool Queue221<T>::Pop()
{
    Node221<T>* cur = head;
	
	//finds the node before tail
	while (cur->next->next) {
		cur = cur->next;
	}
	delete tail;
	//sets tail to the node before the one deleted, then makes the deleted one NULL
	tail = cur;
	tail->next = nullptr;
	
	return 1;
}

template <class T>
bool Queue221<T>::Clear()
{
	Node221<T>* nxt = nullptr;
	//while head exists delete head then set it to the next value in the Queue
	while (head) {
		nxt = head->next;
		delete head;
		head = nxt;
	}
	//set head to NULL
	head = nullptr;
	
	return 1;
}

template class Queue221<int>;

#endif