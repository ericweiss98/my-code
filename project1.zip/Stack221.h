/**************************************************************
 * File:    Stack221.h
 * Project: CSCE 221 - Project 1
 * Author : Eric Weiss
 * Date   : 2/12/19
 * Section: 512
 * E-mail:  ericweiss98@gmail.com
 *
 * Stack221 Class definition.
 *
 *************************************************************/
#ifndef STACK221_H
#define STACK221_H

#include <iostream>
#include <string>
#include "List221.h"

using namespace std;

template <class T>
class Stack221 : public List221<T> {
public:
    /**********************************************************************
     * Name: Stack221 (constructor)
     * PreCondition: none
     * 
     * PostCondition:  creates stack
     *********************************************************************/
    Stack221();
	
    /**********************************************************************
    * Name: Stack221 (Copy Constructor)
    * PreCondition: A stack already exists  
    * 
    * PostCondition:  creates a 2nd stack same as first
    *********************************************************************/
	Stack221(const Stack221& other);
	
    /**********************************************************************
     * Name: Stack221 (destructor)
     * PreCondition: none
     * 
     * PostCondition:  creates stack
     *********************************************************************/
    ~Stack221();
	
    /**********************************************************************
     * Name: Top
     * PreCondition: there is a top.  
     * 
     * PostCondition:  Returns top value
     *********************************************************************/
    T Top();
	
    /**********************************************************************
    * Name: Size
    * PreCondition: None
    * 
    * PostCondition:  Output Queue size
    *********************************************************************/
	int  Size() const;
	
    /**********************************************************************
    * Name: Empty
    * PreCondition: None
    * 
    * PostCondition:  Outputs if list is empty
    *********************************************************************/
	bool Empty() const; 
	
	/**********************************************************************
    * Name: Push
    * PreCondition: List exists
    * 
    * PostCondition:  Adds element to end of list
    *********************************************************************/
	bool Push(T obj);	
	
	/**********************************************************************
    * Name: Pop
    * PreCondition: List exists with at least 1 element
    * 
    * PostCondition:  Removes element from end of list
    *********************************************************************/
	bool Pop();	
	
	/**********************************************************************
    * Name: Clear
    * PreCondition: List exists
    * 
    * PostCondition:  Clears list
    *********************************************************************/
	bool Clear();
    
private:
	T top;
	Node221<T>* head;
};

#include "Stack221.cpp"

#endif