#ifndef NODE221_CPP
#define NODE221_CPP

#include "Node221.h"
#include <iostream>
#include <string>

using namespace std;

template <class T>
Node221<T>::Node221() {
	//makes evevrything point to null initially
	next = nullptr;
	prev = nullptr;
}

template <class T>
Node221<T>::Node221(T data) {
	//sets data in node if given
	data = data;
	next = nullptr;
	prev = nullptr;
}

template class Node221<int>;

#endif