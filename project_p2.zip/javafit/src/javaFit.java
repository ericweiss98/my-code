import java.util.ArrayList;
import java.util.EnumMap;
import javax.swing.*;

/**
 * 
 */

/**
 * @author Glen
 *
 */

public class javaFit extends JPanel {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	  // Load data into app
    Workouts workouts= FileAccess.loadWorkouts();
    EnumMap<Config.MuscleGroup, ArrayList<Config.Muscle>> muscleGroups = FileAccess.loadFormats();
	  
	  // Create Screen Handler
	  MainWindow mainScreen = new MainWindow(workouts, muscleGroups);
	  
	  /*/START CODING
	  //make buttons
	  JButton button1 = new JButton();
	  JButton button2 = new JButton();
	  JButton button3 = new JButton();
	  
	  //set bounds
	  button1.setSize(600,400);
	  button2.setSize(600,400);
	  button3.setSize(600,400);*/

	}

}
