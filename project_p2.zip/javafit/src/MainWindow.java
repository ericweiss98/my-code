import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.EnumMap;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

// Bonus points: Create an icon (or find a public domain icon. Keep in mind federal Copyright law and TAMU's plagiarism policy and add it to the home screen window.
public class MainWindow {
  
  private final JFrame mainFrame = new JFrame(Config.APPLICATIONNAME);
  private final JDialog selectWorkout = new JDialog(mainFrame, "Select Workout");
  private JComboBox<String> cboType, cboGoal;
  private JSpinner spnDuration;
  private final Workouts workouts;
  private final EnumMap<Config.MuscleGroup, ArrayList<Config.Muscle>> muscleGroups;

  private class ButtonListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String command = e.getActionCommand();
		
		mainFrame.getContentPane().removeAll();
		mainFrame.repaint();
		
		if (command.equals(Config.MuscleGroup.UPPERBODY.name())) {
			showWorkouts(muscleGroups.get(Config.MuscleGroup.valueOf("UPPERBODY")));
		}
		if (command.equals(Config.MuscleGroup.LOWERBODY.name())) {
			showWorkouts(muscleGroups.get(Config.MuscleGroup.valueOf("LOWERBODY")));
		}
		if (command.equals(Config.MuscleGroup.WHOLEBODY.name())) {
			showWorkouts(muscleGroups.get(Config.MuscleGroup.valueOf("WHOLEBODY")));
		}

		
	}
	  
	  
  }
  
  MainWindow(Workouts givenWorkouts, EnumMap<Config.MuscleGroup, ArrayList<Config.Muscle>> givenMuscleGroups) {
    // Code goes here.
	  workouts = givenWorkouts;
	  muscleGroups = givenMuscleGroups;
	  
	  launchHomeScreen();
	  
  }
  
  private void launchHomeScreen() {
    // Code goes here.
	  
	  mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  mainFrame.setSize(new Dimension(600,400));
	  
	  JPanel panel = new JPanel();
	  
	  //make buttons
	  JButton upButton = new JButton(Config.MuscleGroup.UPPERBODY.name());
	  JButton lowButton = new JButton(Config.MuscleGroup.LOWERBODY.name());
	  JButton wholeButton = new JButton(Config.MuscleGroup.WHOLEBODY.name());
	  
	  //add buttons
	  panel.add(upButton);
	  panel.add(lowButton);
	  panel.add(wholeButton);

	  //set layout
	  panel.setLayout(new GridLayout(3,1));
	  
	  //adds buttons
	  mainFrame.add(panel);
	  
	  //make visible
	  mainFrame.setVisible(true);
	  
	  //make actionCommand	  
	  upButton.addActionListener(new ButtonListener());
	  lowButton.addActionListener(new ButtonListener());
	  wholeButton.addActionListener(new ButtonListener());
	  
  }
  
  // This is the method your actionlistener should call. It should create and display a WorkoutsPanel.
  private void showWorkouts(ArrayList<Config.Muscle> muscles) {
    
  // Code goes here.
	  
	 WorkoutsPanel panel = new WorkoutsPanel(muscles, workouts);
	 mainFrame.add(panel);
	 mainFrame.validate();
	  
  }
}
